def doDelete(request, session):
